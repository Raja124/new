const $ = (id) => document.getElementById(id);

const questions = [
  { key: 'pilgrims', label: 'Total Mutamers / Number of Pilgrims', type: 'number', placeholder: 'Example: 100' },
  { key: 'startDayMonth', label: 'Start Date — day-month (24-05 or 24-5)', type: 'text', placeholder: 'Day-month, e.g. 24-05' },
  { key: 'endDayMonth', label: 'End Date — day-month (24-05 or 24-5)', type: 'text', placeholder: 'Day-month, e.g. 24-05' },
  { key: 'provider', label: 'Service Provider Name', type: 'text', placeholder: 'Example: ABC Catering' }
];
let stepIndex = 0;
const data = {};
const STATE_KEY = 'nusukAutoFillProgress';

function saveProgress() {
  localStorage.setItem(STATE_KEY, JSON.stringify({ stepIndex, data, location: $('location').value, year: $('year').value, delay: $('delay').value }));
}

function restoreProgress() {
  try {
    const saved = JSON.parse(localStorage.getItem(STATE_KEY) || 'null');
    if (!saved) return;
    if (Number.isInteger(saved.stepIndex) && saved.stepIndex >= 0 && saved.stepIndex < questions.length) stepIndex = saved.stepIndex;
    if (saved.data && typeof saved.data === 'object') Object.assign(data, saved.data);
    if (saved.location) $('location').value = saved.location;
    if (saved.year && [...$('year').options].some(o => o.value === saved.year)) $('year').value = saved.year;
    if (saved.delay && [...$('delay').options].some(o => o.value === saved.delay)) $('delay').value = saved.delay;
  } catch (_) {}
}

const currentYear = new Date().getFullYear();
for (let y = currentYear - 2; y <= currentYear + 8; y++) $('year').insertAdjacentHTML('beforeend', `<option value="${y}">${y}</option>`);
$('year').value = localStorage.getItem('nusukAgreementYear') || String(currentYear);
$('year').addEventListener('change', () => localStorage.setItem('nusukAgreementYear', $('year').value));
restoreProgress();

function showQuestion() {
  const q = questions[stepIndex];
  $('step').innerHTML = `<label for="answer">${q.label}</label><input id="answer" type="${q.type}" placeholder="${q.placeholder}" autocomplete="off">`;
  $('answer').value = data[q.key] || '';
  $('answer').focus();
  $('progress').textContent = `Step ${stepIndex + 1} of ${questions.length}`;
  document.querySelector('.progress-line')?.style.setProperty('--progress', `${Math.round(((stepIndex + 1) / questions.length) * 100)}%`);
  $('next').textContent = stepIndex === questions.length - 1 ? 'Fill Page' : 'Next';
  $('status').textContent = '';
}

async function fillPage(values) {
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const timings = {
    fast: { open: 500, action: 300, verify: 500, pilgrim: 1000, calendarOpen: 700, month: 500, day: 700, startOpen: 1000, startDay: 1000 },
    balanced: { open: 700, action: 500, verify: 700, pilgrim: 1500, calendarOpen: 1000, month: 700, day: 1000, startOpen: 1500, startDay: 1500 },
    safe: { open: 1000, action: 700, verify: 1000, pilgrim: 2500, calendarOpen: 2000, month: 1500, day: 2000, startOpen: 3000, startDay: 3000 }
  };
  const t = timings[values.delay] || timings.balanced;
  const OPEN_WAIT = t.open;
  const ACTION_WAIT = t.action;
  const VERIFY_WAIT = t.verify;
  const PILGRIM_SETTLE_WAIT = t.pilgrim;
  const CALENDAR_OPEN_WAIT = t.calendarOpen;
  const CALENDAR_MONTH_WAIT = t.month;
  const CALENDAR_DAY_WAIT = t.day;
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const visible = el => !!(el && el.offsetWidth && el.offsetHeight && getComputedStyle(el).visibility !== 'hidden');
  const controls = () => [...document.querySelectorAll('input, textarea, select, [role="combobox"], p-dropdown, p-select')].filter(visible);
  const placeholder = (el) => norm(el.getAttribute('placeholder') || el.getAttribute('ng-reflect-placeholder'));
  const byPlaceholder = text => controls().find(el => placeholder(el) === norm(text));
  const click = el => { if (!el) return false; el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.focus?.(); el.click(); return true; };

  function angularSet(el, value) {
    if (!el || value === undefined || value === '') return false;
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, String(value)); else el.value = String(value);
    // These events are needed by Angular reactive forms and PrimeNG.
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: String(value) }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  async function chooseVisibleOption(value) {
    await wait(VERIFY_WAIT);
    const wanted = norm(value).replace(/\s+/g, ' ');
    const candidates = [...document.querySelectorAll('.p-dropdown-panel:not(.p-hidden) li, .p-dropdown-items li, .p-select-list li, [role="option"], p-dropdownitem, p-selectitem, .p-dropdown-item, .p-select-option, .p-autocomplete-option')].filter(visible);
    const textOf = el => norm(el.querySelector('.p-dropdown-item-label, .p-select-option-label, span, a')?.innerText || el.innerText || el.textContent);
    const exact = candidates.find(el => textOf(el) === wanted);
    const found = exact || candidates.find(el => textOf(el).includes(wanted) || wanted.includes(textOf(el)));
    if (!found) return false;
    found.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await wait(ACTION_WAIT);
    // PrimeNG may attach its listener to the nested label, not the outer li.
    const target = found.querySelector('.p-dropdown-item-label, .p-select-option-label, span, a') || found;
    target.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await wait(ACTION_WAIT);
    for (const type of ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      const EventType = type.startsWith('pointer') ? PointerEvent : MouseEvent;
      target.dispatchEvent(new EventType(type, { bubbles: true, cancelable: true, view: window, buttons: type.includes('down') ? 1 : 0 }));
      await wait(60);
    }
    target.focus?.();
    target.click();
    await wait(VERIFY_WAIT);
    return true;
  }

  async function fillDropdown(control, value) {
    if (!control || !value) return false;
    const host = control.matches('p-dropdown, p-select') ? control : (control.closest('p-dropdown, p-select') || control);
    const trigger = host.querySelector('.p-dropdown-trigger, .p-select-dropdown, [role="combobox"]') || host;
    for (let attempt = 0; attempt < 2; attempt++) {
      trigger.scrollIntoView({ block: 'center', behavior: 'smooth' });
      await wait(VERIFY_WAIT);
      trigger.click();
      await wait(VERIFY_WAIT);
      if (await chooseVisibleOption(value)) {
        await wait(ACTION_WAIT);
        const shown = norm(host.innerText || host.textContent);
        if (shown.includes(norm(value))) return true;
      }
      // Keyboard fallback is reliable for PrimeNG when an option row ignores programmatic clicks.
      const keyboardTarget = host.querySelector('[role="combobox"], input') || trigger;
      keyboardTarget.focus?.();
      const press = async (key, code) => {
        keyboardTarget.dispatchEvent(new KeyboardEvent('keydown', { key, code, bubbles: true }));
        await wait(35);
        keyboardTarget.dispatchEvent(new KeyboardEvent('keyup', { key, code, bubbles: true }));
      };
      await press('Home', 'Home');
      await wait(200);
      for (let i = 0; i < 120; i++) {
        await press('ArrowDown', 'ArrowDown');
        const open = [...document.querySelectorAll('.p-dropdown-items li, [role="option"]')].filter(visible);
        const active = open.find(el => el.classList.contains('p-highlight') || el.getAttribute('aria-selected') === 'true');
        if (active && norm(active.innerText || active.textContent).includes(norm(value))) {
          await press('Enter', 'Enter');
          await wait(VERIFY_WAIT);
          if (norm(host.innerText || host.textContent).includes(norm(value))) return true;
          break;
        }
      }
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await wait(ACTION_WAIT);
    }
    return false;
  }

  async function pickCalendar(input, isoDate, isStartDate = false) {
    if (!input || !isoDate) return false;
    const match = String(isoDate).match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (!match) return false;
    const targetYear = Number(match[1]);
    const targetMonth = Number(match[2]) - 1;
    const targetDay = Number(match[3]);
    const host = input.closest('p-calendar') || input.parentElement;
    const calendarButton = host?.querySelector('button[aria-label="Choose Date"]');
    const monthNames = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    const openOverlay = () => [...document.querySelectorAll('.p-datepicker')].filter(visible).pop();
    for (let attempt = 0; attempt < 2; attempt++) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await wait(isStartDate ? 1500 : ACTION_WAIT);
      // The first calendar gets a clean open and an extra settling pause.
      if (isStartDate) click(input); else if (calendarButton) click(calendarButton); else click(input);
      await wait(isStartDate ? t.startOpen : CALENDAR_OPEN_WAIT);

      // PrimeNG renders the open calendar in an overlay. Navigate month by month.
      for (let i = 0; i < 24; i++) {
        const overlay = openOverlay();
        if (!overlay) { await wait(CALENDAR_OPEN_WAIT); continue; }
        const monthEl = overlay.querySelector('.p-datepicker-month');
        const yearEl = overlay.querySelector('.p-datepicker-year');
        const titleText = norm((monthEl?.innerText || '') + ' ' + (yearEl?.innerText || ''));
        const yearMatch = titleText.match(/20\d{2}/);
        let displayedMonth = monthNames.findIndex(m => titleText.includes(m));
        const displayedYear = yearMatch ? Number(yearMatch[0]) : targetYear;
        // Some Nusuk versions render the month title without a class/text node.
        // In that case the calendar opens on the current browser month.
        if (displayedMonth < 0) displayedMonth = new Date().getMonth();
        if (displayedYear === targetYear && displayedMonth === targetMonth) break;
        const direction = (displayedYear < targetYear || (displayedYear === targetYear && displayedMonth < targetMonth)) ? 'next' : 'prev';
        const directSelector = direction === 'next'
          ? '.p-datepicker-next, button[icon="pi pi-chevron-right"], button:has(.pi-chevron-right)'
          : '.p-datepicker-prev, button[icon="pi pi-chevron-left"], button:has(.pi-chevron-left)';
        const directButton = overlay.querySelector(directSelector);
        const button = directButton || [...overlay.querySelectorAll('button, [role="button"]')].find(b => {
          const a = norm(b.getAttribute('aria-label') || b.title || b.innerText);
          return direction === 'next' ? (a.includes('next') || a.includes('right')) : (a.includes('prev') || a.includes('previous') || a.includes('left'));
        });
        if (!button) break;
        click(button);
        await wait(CALENDAR_MONTH_WAIT);
      }

      const overlay = openOverlay();
      if (!overlay) continue;
      const day = [...overlay.querySelectorAll('td:not(.p-disabled):not(.p-datepicker-other-month) span, td:not(.p-disabled):not(.p-datepicker-other-month) button')]
        .filter(visible).find(el => norm(el.innerText || el.textContent) === String(targetDay));
      if (!day) continue;
      click(day);
      await wait(isStartDate ? t.startDay : CALENDAR_DAY_WAIT);
      const expected = `${targetYear}-${String(targetMonth + 1).padStart(2, '0')}-${String(targetDay).padStart(2, '0')}`;
      if (norm(input.value).includes(norm(expected))) return true;
      await wait(CALENDAR_OPEN_WAIT);
    }
    return false;
  }

  let count = 0;
  // 1. Location: click the actual Catering Location control, wait, then select Makkah/Madinah.
  const location = document.querySelector('p-dropdown[formcontrolname="serviceAreaId"]') || byPlaceholder('Catering Location');
  if (await fillDropdown(location, values.location)) count++;

  // 2. Provider: click the actual Service Provider Name control, wait, then select the exact provider.
  const provider = document.querySelector('p-dropdown[formcontrolname="serviceProviderId"]') || byPlaceholder('Service Provider Name');
  if (await fillDropdown(provider, values.provider)) count++;

  // 3. Number: set the actual input, then pause so Angular can update the form.
  const pilgrims = byPlaceholder('Number of Pilgrims') || controls().find(el => el.type === 'number');
  if (pilgrims) {
    pilgrims.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await wait(VERIFY_WAIT);
    pilgrims.focus();
    angularSet(pilgrims, values.pilgrims);
    await wait(VERIFY_WAIT);
    count++;
  }

  // Nusuk refreshes dependent form state after the pilgrim count changes.
  // Give that update time to finish before opening the first calendar.
  await wait(PILGRIM_SETTLE_WAIT);

  // 4. Dates: open the calendar, navigate, and click the day manually.
  let datesCorrect = true;
  for (const [ph, value] of [['Agreement Start Date', values.startDate], ['Agreement End Date', values.endDate]]) {
    const input = byPlaceholder(ph);
    if (!input) continue;
    const selected = await pickCalendar(input, value, ph === 'Agreement Start Date');
    if (selected) count++; else datesCorrect = false;
  }
  if (!datesCorrect) return count;
  // Submit only after every requested field has been filled and the portal has had time to update.
  await wait(VERIFY_WAIT);
  const searchButton = [...document.querySelectorAll('button[type="submit"]')].find(button => norm(button.innerText || button.textContent) === 'search');
  if (searchButton && visible(searchButton)) {
    searchButton.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await wait(ACTION_WAIT);
    searchButton.click();
    await wait(VERIFY_WAIT);
    count++;
  }
  return count;
}

async function submit() {
  $('status').textContent = 'Filling slowly; please wait…';
  $('status').style.color = '#8a6337';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https:\/\/masar\.nusuk\.sa\//i.test(tab.url || '')) throw new Error('Open the Nusuk/Masar page first.');
    const toIso = dm => {
      const raw = String(dm).trim();
      const months = { january: 1, jan: 1, february: 2, feb: 2, march: 3, mar: 3, april: 4, apr: 4, may: 5, june: 6, jun: 6, july: 7, jul: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9, october: 10, oct: 10, november: 11, nov: 11, december: 12, dec: 12 };
      let m = raw.match(/^(\d{1,2})\s*[-\/. ]\s*(\d{1,2})(?:\s*[-\/. ]\s*(\d{4}))?$/);
      if (!m) m = raw.match(/^(\d{1,2})\s+([A-Za-z]+)(?:\s+(\d{4}))?$/);
      if (!m) m = raw.match(/^([A-Za-z]+)\s+(\d{1,2})(?:\s*,?\s*(\d{4}))?$/);
      if (!m && /^\d{3,4}$/.test(raw)) {
        // Compact form is DD-M: 259 => 25 September; DD-MM: 3010 => 30 October.
        m = raw.length === 3
          ? [raw, raw.slice(0, 2), raw.slice(2)]
          : [raw, raw.slice(0, 2), raw.slice(2)];
      }
      if (!m) throw new Error('Enter a valid date, such as 259, 25-09, or 25 September.');
      let day, month, explicitYear;
      if (isNaN(Number(m[2]))) { day = Number(m[1]); month = months[String(m[2]).toLowerCase()]; explicitYear = m[3]; }
      else if (isNaN(Number(m[1]))) { month = months[String(m[1]).toLowerCase()]; day = Number(m[2]); explicitYear = m[3]; }
      else { day = Number(m[1]); month = Number(m[2]); explicitYear = m[3]; }
      if (day < 1 || day > 31 || month < 1 || month > 12) throw new Error('Invalid day or month.');
      return `${explicitYear || $('year').value}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    };
    const values = { ...data, location: $('location').value, delay: $('delay').value, startDate: toIso(data.startDayMonth), endDate: toIso(data.endDayMonth) };
    const result = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: fillPage, args: [values] });
    const count = result?.[0]?.result || 0;
    $('status').textContent = count ? `Completed ${count} field(s). Please review before Search.` : 'No fields were found. Refresh the page and try again.';
    $('status').style.color = count ? '#2e7d32' : '#b3261e';
  } catch (e) {
    $('status').textContent = e.message || 'Could not fill the page.';
    $('status').style.color = '#b3261e';
  }
}

$('next').addEventListener('click', async () => {
  const answer = $('answer');
  if (!answer || !answer.value.trim()) {
    $('status').textContent = 'Please enter this information first.';
    $('status').style.color = '#b3261e';
    return;
  }
  data[questions[stepIndex].key] = answer.value.trim();
  if (stepIndex < questions.length - 1) { stepIndex++; saveProgress(); showQuestion(); } else { saveProgress(); await submit(); }
});
$('step').addEventListener('keydown', e => { if (e.key === 'Enter') $('next').click(); });
$('location').addEventListener('change', saveProgress);
$('delay').addEventListener('change', saveProgress);
$('reset').addEventListener('click', () => { stepIndex = 0; Object.keys(data).forEach(k => delete data[k]); $('location').value = 'Makkah'; localStorage.removeItem(STATE_KEY); saveProgress(); showQuestion(); });
showQuestion();
