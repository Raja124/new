# Nusuk Catering Quick Filler

A small Chrome/Edge Manifest V3 extension for the Nusuk/Masar catering page.

## Install

1. Download and unzip `nusuk-catering-filler.zip`.
2. Open `chrome://extensions` (or `edge://extensions`).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the unzipped `nusuk-catering-filler` folder.

## Use

1. Open the Nusuk/Masar catering page and wait until the fields appear.
2. Click the extension icon.
3. Select **Makkah** or **Madinah** and choose the **Agreement Year** once. The year is remembered in the extension popup.
4. Choose an automation speed: **Fast**, **Balanced** (recommended), or **Safe**.
5. The extension asks one question at a time:
   - Total Mutamers / Number of Pilgrims
   - Start date in any common format, such as `259`, `25-09`, `25 September`, or `25-09-2026`
   - End date in any common format, such as `3010`, `30-10`, `30 October`, or `30-10-2026`
   - Service Provider Name
6. Press **Next** after each answer. On the last question, press **Fill Page**. Dates without a year use the selected year; dates with a year use the year written in the date.
7. After the fields are filled, the extension clicks the page's **Search** button automatically.

If you close the popup or switch to another tab, the current step, answers, location, and year are saved locally. Reopen the extension to continue where you stopped. Use **Start Over** to clear the saved progress.

The extension fills the location, provider, pilgrim total, and agreement dates. Kitchen Type is left unchanged because it is not requested in this workflow. The extension only runs when you click **Fill Page** on an `https://masar.nusuk.sa/` page. It does not save or send the entered data.
